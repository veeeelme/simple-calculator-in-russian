def perimetr_rectangle(a, b):
    return print(f'Периметр: {(a * 2) + (b * 2)} см')


def area_rectangle(a, b):
    return print(f'Площадь: {a * b} см')


def perimetr_square(a):
    return print(f'Периметр: {a * 4} см')


def area_square(a):
    return print(f'Площадь: {a ** 2} см')


def periment_triangle(a, b, c):
    return print(f'Площадь: {a + b + c} см')


def perimetr_parallelepiped(a, b, c):
    return print(f'{a * 4 + b * 4 + c * 4} см')


def surface_area_parallelepiped(a, b, c):
    return print(f'{2 * (a * b + a * c + b * c)} см')


def volume_of_parallelepiped(a, b, c):
    return print(f'{a * b * c} кубич. см')
